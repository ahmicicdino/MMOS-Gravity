package com.example.mmos_ahmicic_gravity;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.media.AudioManager;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.TextView;
import android.content.Context;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;


public class MainActivity extends AppCompatActivity implements SensorEventListener{

    private TextView xTextView, yTextView, zTextView; //varijable za ispis iznosa gravitacije za svaku os
    private SensorManager sensorManager;    //poziva senzor, u ovom slucaju gravity senzor
    private Sensor mGravity;
    private boolean isGravitySensorPresent;  //varijabla kojom provjeravamo da li je senzor dostupan


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        xTextView = findViewById(R.id.xTextViev);       //povezivanje na text view x osi koji smo stavili unutar activity_main.xml
        yTextView = findViewById(R.id.yTextViev);       //povezivanje na text view y osi koji smo stavili unutar activity_main.xml
        zTextView = findViewById(R.id.zTextViev);       //povezivanje na text view z osi koji smo stavili unutar activity_main.xml


        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);       //pozivanje usluge svih dostupnih senzora

        if (sensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY) != null){       //ako je TYPE_GRAVITY senzor dostupan
            mGravity = sensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY);     //pozivanje senzora i spremanje u varijablu mGravity
            isGravitySensorPresent = true;                                      //senzor je dostupan
        }
        else{                                                                   //u slucaju da senzor nije dostupan
            xTextView.setText("Sensor is not present");
            isGravitySensorPresent = false;                                     //varijabla postaje false
        }
    }



    @Override
    public void onSensorChanged(SensorEvent event) {
        xTextView.setText(event.values[0] + "m/s2");                    //prikaz iznosa gravitacije X osi
        yTextView.setText(event.values[1] + "m/s2");                    //prikaz iznosa gravitacije Y osi
        zTextView.setText(event.values[2] + "m/s2");                    //prikaz iznosa gravitacije Z osi

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    @Override
    protected void onResume() {
        super.onResume();
        if(sensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY) != null)
            sensorManager.registerListener(this, mGravity, SensorManager.SENSOR_DELAY_NORMAL); //Registriranje slusatelja/listenera sa onResume callback metodom
    }

    @Override
    protected void onPause() {
        super.onPause();
        if(sensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY) != null)
            sensorManager.unregisterListener(this, mGravity);       //Brisanje slusatelja/listenera callback metodom onPausell
    }
}